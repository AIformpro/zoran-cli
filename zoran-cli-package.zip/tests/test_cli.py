from click.testing import CliRunner
from zcli import cli

def test_new_command():
    runner = CliRunner()
    result = runner.invoke(cli.cli, ["new"])
    assert result.exit_code == 0
    assert "New project created." in result.output
