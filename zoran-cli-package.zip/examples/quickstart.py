# Example usage of zoran-cli via subprocess
import subprocess

commands = [["new"], ["encode"], ["inject"], ["bench"], ["mint"]]
for cmd in commands:
    result = subprocess.run(["python", "-m", "zcli.cli"] + cmd, capture_output=True, text=True)
    print(result.stdout)
