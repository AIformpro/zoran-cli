import click

@click.group()
def cli():
    pass

@cli.command()
def new():
    click.echo("New project created.")

@cli.command()
def encode():
    click.echo("Data encoded.")

@cli.command()
def inject():
    click.echo("Injector executed.")

@cli.command()
def bench():
    click.echo("Benchmark completed.")

@cli.command()
def mint():
    click.echo("Minting successful.")

if __name__ == '__main__':
    cli()
